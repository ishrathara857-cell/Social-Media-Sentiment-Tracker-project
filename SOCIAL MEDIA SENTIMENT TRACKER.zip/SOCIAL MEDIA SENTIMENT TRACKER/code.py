import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# =====================================
# PAGE CONFIG
# =====================================

st.set_page_config(
    page_title="Social Media Sentiment Tracker",
    page_icon="📊",
    layout="wide"
)

st.title("📊 Social Media Sentiment Tracker")
st.write("Data Science Internship Project")

# =====================================
# LOAD DATA
# =====================================

df = pd.read_csv(
    "twitter_training.csv",
    header=None,
    names=["ID", "Topic", "Sentiment", "Tweet"]
)

# Remove missing tweets
df = df.dropna()

# =====================================
# SIDEBAR
# =====================================

st.sidebar.header("Filters")

topics = st.sidebar.multiselect(
    "Select Topic",
    df["Topic"].unique(),
    default=df["Topic"].unique()[:5]
)

if topics:
    filtered_df = df[df["Topic"].isin(topics)]
else:
    filtered_df = df

# =====================================
# DATA PREVIEW
# =====================================

st.subheader("Dataset Preview")
st.dataframe(filtered_df.head(10))

# =====================================
# KPI CARDS
# =====================================

st.subheader("Key Metrics")

col1, col2, col3 = st.columns(3)

col1.metric(
    "Total Posts",
    len(filtered_df)
)

col2.metric(
    "Topics",
    filtered_df["Topic"].nunique()
)

col3.metric(
    "Sentiment Types",
    filtered_df["Sentiment"].nunique()
)

# =====================================
# SENTIMENT DISTRIBUTION
# =====================================

st.subheader("Sentiment Distribution")

fig, ax = plt.subplots(figsize=(8,5))

sns.countplot(
    data=filtered_df,
    x="Sentiment",
    ax=ax
)

plt.xticks(rotation=20)

st.pyplot(fig)

# =====================================
# PIE CHART
# =====================================

st.subheader("Sentiment Percentage")

sentiment_counts = filtered_df["Sentiment"].value_counts()

fig, ax = plt.subplots(figsize=(6,6))

ax.pie(
    sentiment_counts,
    labels=sentiment_counts.index,
    autopct="%1.1f%%"
)

st.pyplot(fig)

# =====================================
# TOP TOPICS
# =====================================

st.subheader("Top Discussed Topics")

topic_counts = filtered_df["Topic"].value_counts().head(10)

fig, ax = plt.subplots(figsize=(10,5))

topic_counts.plot(
    kind="bar",
    ax=ax
)

ax.set_ylabel("Number of Posts")

st.pyplot(fig)

# =====================================
# SENTIMENT BY TOPIC
# =====================================

st.subheader("Sentiment by Topic")

sentiment_topic = pd.crosstab(
    filtered_df["Topic"],
    filtered_df["Sentiment"]
)

st.dataframe(sentiment_topic.head(20))

# =====================================
# TWEET SEARCH
# =====================================

st.subheader("Search Tweets")

search_text = st.text_input(
    "Enter keyword"
)

if search_text:
    result = filtered_df[
        filtered_df["Tweet"]
        .str.contains(
            search_text,
            case=False,
            na=False
        )
    ]

    st.write(
        f"Found {len(result)} matching tweets"
    )

    st.dataframe(
        result.head(20)
    )

# =====================================
# SAMPLE TWEETS
# =====================================

st.subheader("Sample Tweets")

st.dataframe(
    filtered_df[
        ["Topic",
         "Sentiment",
         "Tweet"]
    ].sample(10)
)

# =====================================
# BUSINESS INSIGHTS
# =====================================

st.subheader("Insights")

most_common_topic = (
    filtered_df["Topic"]
    .value_counts()
    .idxmax()
)

most_common_sentiment = (
    filtered_df["Sentiment"]
    .value_counts()
    .idxmax()
)

st.success(
    f"Most Discussed Topic: {most_common_topic}"
)

st.success(
    f"Dominant Sentiment: {most_common_sentiment}"
)

st.success(
    f"Total Records Analyzed: {len(filtered_df)}"
)

st.balloons()

st.markdown("---")
st.markdown(
    "### Social Media Sentiment Analysis Completed"
)